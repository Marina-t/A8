#include "ray_intersect_box.h"
#include <iostream>

bool ray_intersect_box( 
  const Ray & ray,
  const BoundingBox& box,
  const double min_t,
  const double max_t,
  double & t)
{
  /* Using the concepts discussed in section 12.3 from the assigned book */
    
  // Use a lamda expression to calculate the min and max parametric distances for each dimension
  auto get_interval = [& ray, & box](int axis, double & min_t, double & max_t) {
  	if (ray.direction[axis] == 0) {
  		min_t = (box.min_corner[axis] > ray.origin[axis]) ? 
  		    std::numeric_limits<double>::infinity() : - std::numeric_limits<double>::infinity();
  		max_t = (box.max_corner[axis] > ray.origin[axis]) ? 
  		    std::numeric_limits<double>::infinity() : - std::numeric_limits<double>::infinity();
  	}
  	else {
  		if (ray.direction[axis] > 0) {
  			min_t = (box.min_corner[axis] - ray.origin[axis]);
  			max_t = (box.max_corner[axis] - ray.origin[axis]);
  		}
  		else {
  			min_t = (box.max_corner[axis] - ray.origin[axis]);
  			max_t = (box.min_corner[axis] - ray.origin[axis]);
  		}
  		min_t = min_t / ray.direction[axis];
  		max_t = max_t / ray.direction[axis];
  	}
  };

  double tx_min, tx_max, ty_min, ty_max, tz_min, tz_max;
  get_interval(0, tx_min, tx_max);
  get_interval(1, ty_min, ty_max);
  get_interval(2, tz_min, tz_max);

  if ((tx_min > ty_max) || (tx_min > tz_max) || (ty_min > tx_max) || (ty_min > tz_max) || 
  	  (tz_min > tx_max) || (tz_min > ty_max)) {
  	return false;
  }

  t = 0; // we don't actually care about the value of t (the distance), just if we intersect the box or not
  return true;
}
