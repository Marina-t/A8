#include "ray_intersect_triangle.h"
#include <Eigen/Dense>

#include <iostream>

bool ray_intersect_triangle(
  const Ray & ray,
  const Eigen::RowVector3d & A,
  const Eigen::RowVector3d & B,
  const Eigen::RowVector3d & C,  
  const Eigen::RowVector3d & Na,
  const Eigen::RowVector3d & Nb,
  const Eigen::RowVector3d & Nc,
  const double min_t,
  double & t,
  Eigen::Vector3d & n)
{  
  
  //std::cout << "ray_intersect_triangle" << std::endl;

  Eigen::Vector3d vertex_A = A.transpose();
  Eigen::Vector3d vertex_B = B.transpose();
  Eigen::Vector3d vertex_C = C.transpose();

  Eigen::Vector3d side_AB = vertex_B - vertex_A;
  Eigen::Vector3d side_AC = vertex_C - vertex_A;

  Eigen::Vector3d triangle_normal = side_AB.cross(side_AC);

  /* Find the 't' at which the ray intersects the plane of the triangle (if it exists) 
   * From A2 - A3 code of ray - plane intersection
   */
  // std::cout << "ray_intersect_triangle here 1 " << std::endl;
  double denominator = ray.direction.dot(triangle_normal);
  if (denominator == 0) {    
    return false;
  }

  double numerator = (vertex_A - ray.origin).dot(triangle_normal);

  double distance = numerator / denominator;

  if ((distance < min_t)) {
    return false;
  }

  //std::cout << "plane was hit" << std::endl;

  /* Next, check if the point e + td (the point of intersection with the plane) 
   * lies within the triangle --> I used the method outlined in the book
   * Chapter 2
   */
  Eigen::Vector3d intersection_pt = ray.origin + (distance * ray.direction);

  Eigen::Vector3d side_BC = vertex_C - vertex_B;
  Eigen::Vector3d side_CA = vertex_A - vertex_C;

  Eigen::Vector3d side_AP = intersection_pt - vertex_A;
  Eigen::Vector3d side_BP = intersection_pt - vertex_B;
  Eigen::Vector3d side_CP = intersection_pt - vertex_C;

  Eigen::Vector3d normal_a = side_BC.cross(side_BP);
  Eigen::Vector3d normal_b = side_CA.cross(side_CP);
  Eigen::Vector3d normal_c = side_AB.cross(side_AP);

  double alpha = (triangle_normal.dot(normal_a)) /  (triangle_normal.squaredNorm());
  double beta =  (triangle_normal.dot(normal_b)) /  (triangle_normal.squaredNorm());
  double gamma =  (triangle_normal.dot(normal_c)) / (triangle_normal.squaredNorm());
  
  if ((alpha < 0) || (alpha > 1) || (beta < 0) || (beta > 1) || (gamma < 0) || (gamma > 1)) {
    return false;
  }
  
  t = distance;
  Eigen::Vector3d interp_normal = (alpha * Na) + (beta * Nb) + (gamma * Nc);
  n = interp_normal.normalized();

  return true;

}
