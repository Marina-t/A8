#include "EnvironmentMapper.h"
#include <algorithm>
#include <math.h>
#include <limits>
#include <igl/png/readPNG.h>
#include <iostream>
#include <string>

EnvironmentMapper::EnvironmentMapper(const std::string png_file)
{
  Eigen::Matrix<unsigned char,Eigen::Dynamic,Eigen::Dynamic> _R;
  Eigen::Matrix<unsigned char,Eigen::Dynamic,Eigen::Dynamic> _G;
  Eigen::Matrix<unsigned char,Eigen::Dynamic,Eigen::Dynamic> _B;
  Eigen::Matrix<unsigned char,Eigen::Dynamic,Eigen::Dynamic> A;
  igl::png::readPNG(png_file, _R, _G, _B, A);

  this->R = _R.cast<double>();
  this->G = _G.cast<double>();
  this->B = _B.cast<double>();  
}

Eigen::Vector3d EnvironmentMapper::ray_intersect(const Eigen::Vector3d & direction) const
{
  // using concepts from the following sources:
  // 1. the book chapter 11
  // 2. this blog post's explanation https://scalibq.wordpress.com/2013/06/23/cubemaps/
  double x, y, z;
  x = std::fabs(direction(0));
  y = std::fabs(direction(1));
  z = std::fabs(direction(2));

  double max_coord = std::max(x, std::max(y, z));

  bool walls = false; // whether the ray hit the "walls" or the floor/ceiling
  double u, v;

  Eigen::Vector3d colour = Eigen::Vector3d(1,1,1);

  if (max_coord == x) {
    walls = true;

    double numerator = direction(0) > 0 ? -direction(2) : direction(2);
    u = ((numerator / x) + 1) / 2;
    v = (((-direction(1)) / x) + 1) / 2;
  }  

  if (max_coord == z) {
    walls = true;

    double numerator = direction(2) > 0 ? direction(0) : -direction(0);
    u = ((numerator / z) + 1) / 2;
    v = (((-direction(1)) / z) + 1) / 2;
  }

  if (max_coord == y) {
    walls = false;

    double numerator = direction(1) > 0 ? direction(2) : -direction(2);
    u = (((direction(0)) / y) + 1) / 2;
    v = ((numerator / y) + 1) / 2;
  }

  if (walls) {
    int idx_u = int(std::floor(u * this->R.cols()));
    int idx_v = int(std::floor(v * this->R.rows()));
    
    colour = Eigen::Vector3d(this->R(idx_v, idx_u)/255.0, this->G(idx_v, idx_u)/255.0, this->B(idx_v, idx_u)/255.0);    
  }

  return colour;

}
