#include "insert_box_into_box.h"
#include <algorithm>

void insert_box_into_box(
  const BoundingBox & A,
  BoundingBox & B)
{
  
  /* Find the minimum corner of the box */
  Eigen::RowVector3d min_corner = Eigen::RowVector3d(0, 0, 0);
  min_corner[0] = std::min(A.min_corner[0], B.min_corner[0]);
  min_corner[1] = std::min(A.min_corner[1], B.min_corner[1]);
  min_corner[2] = std::min(A.min_corner[2], B.min_corner[2]);

  /* Find the maximum corner of the box */
  Eigen::RowVector3d max_corner = Eigen::RowVector3d(0, 0, 0);
  max_corner[0] = std::max(A.max_corner[0], B.max_corner[0]);
  max_corner[1] = std::max(A.max_corner[1], B.max_corner[1]);
  max_corner[2] = std::max(A.max_corner[2], B.max_corner[2]);
  
  B.min_corner = min_corner;
  B.max_corner = max_corner;
}

