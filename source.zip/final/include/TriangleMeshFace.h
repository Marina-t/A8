#ifndef TRIANGLE_MESH_FACE
#define TRIANGLE_MESH_FACE

#include "Object.h"
#include <Eigen/Core>
#include <memory>
#include <iostream>

struct TriangleMeshFace : public Object
{
  public:
    // Pointer to mesh vertex position list
    const Eigen::MatrixXd & V;
    // Pointer to mesh indices list
    const Eigen::MatrixXi & F;
    // Pointer to mesh per corner normals list
    const Eigen::MatrixXd & N;
    // face index
    int f;

    // Record with vertex and face set this TriangleMeshFace references _and_
    // compute bounding box for this triangle.
    //
    // Inputs:
    //   V  pointer to mesh vertex list
    //   F  pointer to mesh face list
    //   N  pointer to per-corner normals list
    //   f  index of triangle in _F
    // Side effects: inserts this triangle into .box (see Object.h)
    inline TriangleMeshFace(
      const Eigen::MatrixXd & V,
      const Eigen::MatrixXi & F,
      const Eigen::MatrixXd & N,
      const int f);

    // Object implementations (see Object.h)
    inline bool ray_intersect(
      const Ray& ray,
      const double min_t,
      double & t,
      Eigen::Vector3d & n) const override;
};


// Implementation

#include "insert_triangle_into_box.h"
#include "ray_intersect_triangle.h"

inline TriangleMeshFace::TriangleMeshFace(
    const Eigen::MatrixXd & _V,
    const Eigen::MatrixXi & _F,
    const Eigen::MatrixXd & _N,
    const int _f): V(_V), F(_F), N(_N), f(_f)
{

  insert_triangle_into_box(
    V.row(F(f,0)),
    V.row(F(f,1)),
    V.row(F(f,2)),
    box);
}

// Simple wrapper around `ray_intersect_triangle`
inline bool TriangleMeshFace::ray_intersect(
  const Ray& ray,
  const double min_t,
  double & t,
  Eigen::Vector3d & n) const
{
  
  int normal_start_idx = f * F.cols();
  
  return ray_intersect_triangle(
    ray,
    V.row(F(f,0)),
    V.row(F(f,1)),
    V.row(F(f,2)),
    N.row(normal_start_idx),
    N.row(normal_start_idx + 1),
    N.row(normal_start_idx + 2),
    min_t,
    t,
    n);  
}

#endif
