#ifndef ENVIRONMENT_MAPPER_H
#define ENVIRONMENT_MAPPER_H

#include <Eigen/Core>
#include <memory>
#include <vector>
#include <string>

struct EnvironmentMapper 
{
  Eigen::MatrixXd R;
  Eigen::MatrixXd G;
  Eigen::MatrixXd B;

  EnvironmentMapper(const std::string png_file);

  Eigen::Vector3d ray_intersect(const Eigen::Vector3d & direction) const;
};

#endif
