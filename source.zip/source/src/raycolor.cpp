#include "raycolor.h"
#include "first_hit.h"
#include "blinn_phong_shading.h"

#include <algorithm>
#include <math.h>
#include <limits>
#include <memory>
#include <iostream>

// generates the reflected ray, given the viewing direction
Eigen::Vector3d reflect(const Eigen::Vector3d & in, const Eigen::Vector3d & n)
{
  Eigen::Vector3d reflection_dir = in - (2 * (in.dot(n)) * n);
  return reflection_dir;
}

// generates the refracted ray, given the viewing direction, normal and refraction index ratio (w.r.t air)
bool refract(const Eigen::Vector3d & in, const Eigen::Vector3d & n, const double ref_ratio, Eigen::Vector3d & refracted) {
  Eigen::Vector3d in_norm = in.normalized();
  float cos_angle = in_norm.dot(n); 
  float sqrt_term = 1.0 - (pow(ref_ratio, 2.0) * (1 - pow(cos_angle, 2.0)));

  if (sqrt_term > 0) {
    refracted = (ref_ratio * (in_norm - (n * cos_angle))) - (n * sqrt(sqrt_term));
    return true;
  }
  else 
    return false;
}

bool raycolor(
  const Ray & ray, 
  const double min_t,
  const std::vector< std::shared_ptr<Object> > & objects,
  const std::vector< std::shared_ptr<Light> > & lights,
  const EnvironmentMapper & env_mapper,
  const int num_recursive_calls,
  Eigen::Vector3d & rgb)
{  
  int NUM_REC_CALLS = 10; 
  double EPS = 1e-3;

  // check if the ray hits an object in the scene
  int hit_id;
  double hit_t;
  Eigen::Vector3d hit_n; // hit_n is the unit normal at the point of intersection
  
  if (!first_hit(ray, min_t, objects, hit_id, hit_t, hit_n)) { 
    Eigen::Vector3d _rgb = env_mapper.ray_intersect(ray.direction);
    rgb(0) = _rgb(0);
    rgb(1) = _rgb(1);
    rgb(2) = _rgb(2);    
    return false;
  }

  /* The viewing ray hits an object in the scene */
  std::shared_ptr<Object> hit_object = objects[hit_id];

  // =============================== A Dielectric material ====================== //

  // using concepts from:
  // 1. the textbook chapter 13
  // 2. the book: "Ray Tracing in one weekend"

  if (hit_object->material->refract_idx > 0 && num_recursive_calls < NUM_REC_CALLS) {

    Eigen::Vector3d hit_point = ray.origin + (hit_t * ray.direction);    
    Eigen::Vector3d outward_normal;

    Eigen::Vector3d transmitted;
    Eigen::Vector3d reflected = reflect(ray.direction, hit_n);

    float ref_ratio;
    
    float cos_angle;

    if (ray.direction.normalized().dot(hit_n) < 0) {
      // the angle between the viewing direction and the normal > 90 (going into the material)
      outward_normal = hit_n;
      ref_ratio = hit_object->material->refract_idx;
      cos_angle = -ray.direction.normalized().dot(hit_n.normalized());
    }
    else {
      // the angle between the viewing ray and the normal >= 90 (going out or total internal reflection)
      outward_normal = -hit_n;
      ref_ratio = 1.0 / hit_object->material->refract_idx;
      cos_angle = ray.direction.normalized().dot(hit_n.normalized());
    }

    Ray reflected_ray;
    reflected_ray.origin = hit_point;
    reflected_ray.direction = reflected;

    Eigen::Vector3d reflected_rgb = Eigen::Vector3d(0.0, 0.0, 0.0);
    raycolor(reflected_ray, EPS, objects, lights, env_mapper, (num_recursive_calls + 1), reflected_rgb);

    if (!refract(ray.direction, outward_normal, ref_ratio, transmitted)) {
      // total internal reflection
      rgb += reflected_rgb;
      return true;
    }
    else {

      if (ray.direction.normalized().dot(hit_n) > 0) {
        cos_angle = transmitted.normalized().dot(hit_n.normalized());
      }

      // some part of the ray is transmitted (the Schlick's approximation for the Fresnel equation)
      float R_0 = (hit_object->material->refract_idx - 1.0) / (hit_object->material->refract_idx + 1);
      R_0 = pow(R_0, 2.0);      
      float R = R_0 + (1.0 - R_0) * pow((1.0 - cos_angle), 5.0); 

      Ray transmitted_ray;
      transmitted_ray.origin = hit_point;
      transmitted_ray.direction = transmitted;

      Eigen::Vector3d transmitted_rgb = Eigen::Vector3d(0,0,0);

      raycolor(transmitted_ray, EPS, objects, lights, env_mapper, (num_recursive_calls + 1), transmitted_rgb);

      rgb += rgb + (R * reflected_rgb) + ((1- R) * transmitted_rgb);
      return true;
    }
    
  }

  rgb += blinn_phong_shading(ray, hit_id, hit_t, hit_n, objects, lights);
  

  // =============================== Mirror Reflections ========================== //
  if ((hit_object->material->km[0] != 0 || hit_object->material->km[1] != 0 || hit_object->material->km[2] != 0) && 
    (num_recursive_calls < NUM_REC_CALLS)) {
    
    Eigen::Vector3d viewing_dir = ray.direction.normalized();
    Eigen::Vector3d hit_point = ray.origin + (hit_t * ray.direction);

    Eigen::Vector3d reflection_dir = reflect(ray.direction, hit_n);

    Ray reflection_ray;
    reflection_ray.origin = hit_point;
    reflection_ray.direction = reflection_dir;

    Eigen::Vector3d reflection_rgb = Eigen::Vector3d(0, 0, 0);

    raycolor(reflection_ray, EPS, objects, lights, env_mapper, (num_recursive_calls + 1), reflection_rgb);

    rgb += (hit_object->material->km.array() * reflection_rgb.array()).matrix();
  }

  return true;
}
