#include "blinn_phong_shading.h"
// Hint:
#include "first_hit.h"
#include <iostream>

Eigen::Vector3d blinn_phong_shading(
  const Ray & ray,
  const int & hit_id, 
  const double & t,
  const Eigen::Vector3d & n,
  const std::vector< std::shared_ptr<Object> > & objects,
  const std::vector<std::shared_ptr<Light> > & lights)
{

  Eigen::Vector3d rgb_color = Eigen::Vector3d(0, 0, 0);

  Eigen::Vector3d viewing_dir = ray.direction.normalized();
  Eigen::Vector3d hit_point = ray.origin + (t * ray.direction);
  std::shared_ptr<Object> hit_object = objects[hit_id];
  
  // add the ambient colour 
  rgb_color += hit_object->material->ka; 

  Eigen::Vector3d light_dir;
  double light_dist;
  Ray shadow_ray;
  int shadow_hit_id;
  double shadow_hit_t;
  Eigen::Vector3d shadow_hit_n;
  Eigen::Vector3d h;
  for (std::shared_ptr<Light> light : lights) {

    light->direction(hit_point, light_dir, light_dist);

    light_dir = light_dir.normalized(); 

    shadow_ray.origin = hit_point;
    shadow_ray.direction = light_dir;

    // check if the ray from the point hits any objects in the scene before making it to the light
    if ((!first_hit(shadow_ray, 1e-9, objects, shadow_hit_id, shadow_hit_t, shadow_hit_n)) || 
        (shadow_hit_t > light_dist)) {

      /* The current point is not in the shadow of any other object */

      // find the halfway vector
      h = (( -1 * viewing_dir) + light_dir).normalized();

      rgb_color += (hit_object->material->kd.array() * light->I.array()).matrix() * std::max(0.0, n.dot(light_dir));

      rgb_color += (hit_object->material->ks.array() * light->I.array()).matrix() * 
             (pow(std::max(0.0, h.dot(n)), hit_object->material->phong_exponent));

    }
  }

  return rgb_color;
}
