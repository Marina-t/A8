#include "AABBTree.h"
#include "insert_box_into_box.h"
#include <algorithm>
#include <cmath>
#include <limits>

#include <iostream>

AABBTree::AABBTree(
  const std::vector<std::shared_ptr<Object> > & objects,
  int a_depth): 
  depth(std::move(a_depth)), 
  num_leaves(objects.size())
{
  /* Using the algorithm outlined in the book Chapter 12 */
  
  int objects_num = objects.size();

  if (objects_num == 1) {
    this->left = objects[0];
    this->right = NULL;
    this->box = BoundingBox(objects[0]->box.min_corner, objects[0]->box.max_corner);
  }
  else if (objects_num == 2) {
    this->left = objects[0];
    this->right = objects[1];

    this->box = BoundingBox(objects[0]->box.min_corner, objects[0]->box.max_corner);
    insert_box_into_box(objects[1]->box, this->box);
  }
  else {
    
    /* Find the min and max corner of the box that includes all of the provided objects */    
    Eigen::Vector3d min_vals = objects[0]->box.min_corner;
    Eigen::Vector3d max_vals = objects[0]->box.max_corner;

    int obj_ind;
    for (obj_ind = 1; obj_ind < objects_num; obj_ind++) {
      min_vals[0] = std::min(min_vals[0], objects[obj_ind]->box.min_corner[0]);
      min_vals[1] = std::min(min_vals[1], objects[obj_ind]->box.min_corner[1]);
      min_vals[2] = std::min(min_vals[2], objects[obj_ind]->box.min_corner[2]);

      max_vals[0] = std::max(max_vals[0], objects[obj_ind]->box.max_corner[0]);
      max_vals[1] = std::max(max_vals[1], objects[obj_ind]->box.max_corner[1]);
      max_vals[2] = std::max(max_vals[2], objects[obj_ind]->box.max_corner[2]);
    }

    /* Find the longest axis, along which we will split our objects */
    Eigen::Vector3d diff_vals = (max_vals - min_vals);    

    int split_axis = 0;
    double max_diff = std::abs(diff_vals[0]);
    for (int axis = 1; axis < 3; axis++) {
    	double curr_diff = std::abs(diff_vals[axis]);
    	if (curr_diff > max_diff) {
    		max_diff = curr_diff;
    		split_axis = axis;
    	}
    }

    double split_point = 0.5 * (min_vals[split_axis] + max_vals[split_axis]);

    std::vector<std::shared_ptr<Object>> left_objects;
    std::vector<std::shared_ptr<Object>> right_objects;

    Eigen::RowVector3d curr_obj_center;
    for (obj_ind = 0; obj_ind < objects_num; obj_ind++) {
    	curr_obj_center = objects[obj_ind]->box.center();
    	
    	if (curr_obj_center[split_axis] < split_point) {
        left_objects.push_back(objects[obj_ind]);
    	}
    	else {
        right_objects.push_back(objects[obj_ind]);
      }
    }

    /* To prevent code from recursing forever, if we find that all objects ended up
     * on one side, we will move the last object in the full list to the other list 
     */
    if (left_objects.size() == 0 && right_objects.size() > 2) {
    	left_objects.push_back(right_objects[right_objects.size() - 1]);
    	right_objects.pop_back();
    }
    else if (right_objects.size() == 0 && left_objects.size() > 2) {
    	right_objects.push_back(left_objects[left_objects.size() - 1]);
    	left_objects.pop_back();
    }

    this->left = NULL;
    this->right = NULL;

    /* create the box on the left */
    if (left_objects.size() > 0) {
      this->left = std::make_shared<AABBTree>(left_objects, a_depth + 1);
    }

    /* create the box on the right */
    if (right_objects.size() > 0) {
      this->right = std::make_shared<AABBTree>(right_objects, a_depth + 1);
    }

    /* create the current box */
    this->box = BoundingBox(this->left->box.min_corner, this->left->box.max_corner);
    insert_box_into_box(this->right->box, this->box);    
  }
}

bool AABBTree::ray_intersect(
  const Ray& ray,
  const double min_t,
  double & t,
  Eigen::Vector3d & n) const 
{
  /* Using the algorithm outlined in the book Chapter 12 */
  double curr_t = 0;
  double max_t = std::numeric_limits<double>::infinity();
  if (!ray_intersect_box(ray, this->box, min_t, max_t, curr_t)) {
    return false;
  }

  bool left_hit = false, right_hit = false;
  double left_t, right_t;
  Eigen::Vector3d left_n;
  Eigen::Vector3d right_n; 

  if (this->left != NULL) {
    left_hit = this->left->ray_intersect(ray, min_t, left_t, left_n);
  }

  if (this->right != NULL) {
    right_hit = this->right->ray_intersect(ray, min_t, right_t, right_n);
  }

  if (!left_hit && !right_hit) {
    return false;
  }

  if (left_hit) {    
    t = left_t;
    n = left_n;
  }

  if (right_hit && (!left_hit || (right_t < left_t))) {
    t = right_t;
    n = right_n;
  }

  return true;
}
