#include "first_hit.h"
#include <limits>

bool first_hit(
  const Ray & ray, 
  const double min_t,
  const std::vector< std::shared_ptr<Object>> & objects,
  int & hit_object, 
  double & t,
  Eigen::Vector3d & n)
{
  double min_distance = std::numeric_limits<double>::infinity();
  int hit_obj = -1;
  Eigen::Vector3d hit_norm;

  double curr_distance;
  Eigen::Vector3d curr_norm; 
  bool curr_result;
  for (int i = 0; i < objects.size(); i++) {
    curr_result = objects[i]->ray_intersect(ray, min_t, curr_distance, curr_norm);
    
    if (curr_result && (curr_distance >= min_t) && (curr_distance < min_distance)) {
      min_distance = curr_distance;
      hit_obj = i;
      hit_norm = curr_norm;
    }
  }

  if (hit_obj != -1) {
    hit_object = hit_obj;
    t = min_distance;
    n = hit_norm;
    return true;
  }

  return false;
}
