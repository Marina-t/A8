#include "Camera.h"
#include "DirectionalLight.h"
#include "Object.h"
#include "AABBTree.h"
#include "Ray.h"
#include "raycolor.h"
#include "Material.h"
#include "TriangleMeshFace.h"
#include "EnvironmentMapper.h"

#include <limits>
#include <igl/read_triangle_mesh.h>
#include <igl/png/writePNG.h>
#include <igl/per_corner_normals.h>
#include <iostream>

/* ========================= STATIC PROPERTIES ========================= */
// relative path to the data directory
std::string data_dir = "../data/";

// paths of the obj files containing the meshes
std::vector<std::string> meshes = 
{
	"lava_lamp_glass.obj", "lava_lamp_obj1.obj", "lava_lamp_obj2.obj",
	"lava_lamp_obj3.obj", "lava_lamp_top.obj", "lava_lamp_base.obj"
};

std::string out_image_name = "image.png";

/* ================================ Helper Functions ================================ */
void viewing_ray(
	const Camera & camera, const int i, const int j, const int width, const int height, Ray & ray)
{
	ray.origin = camera.e;

	/* To calculate the ray's direction, we first need to calculate the pos of the pixel
	* assuming that the bottom left corner is (0, 0)
	*/
	double left = 0 - (camera.width / 2);
	double bottom = (camera.height / 2);
	double u = left + ((camera.width / width) * (j + 0.5));
	double v = bottom - ((camera.height / height) * (i + 0.5));

	ray.direction = (-1 * camera.d * camera.w) + (u * camera.u) + (v * camera.v);
}

/* ================================ MAIN ================================ */
int main(int argc, char * argv[])
{
	// image dimensions
	int img_width = 1920;
	int img_height = 1080;

	// the camera
	Camera camera;
	camera.e = Eigen::Vector3d(0.0, 0.0, 35.0);
	camera.v = Eigen::Vector3d(0.0, 1.0, 0.0).normalized();
	camera.w = -1 * Eigen::Vector3d(0.0, 0.0, -1.0).normalized();
	camera.u = camera.v.cross(camera.w);
	camera.d = 3.0;
	camera.height = 1.0;
	camera.width = 1.7777777778;

	// the light
	std::vector<std::shared_ptr<Light>> lights;
	std::shared_ptr<DirectionalLight> light = std::make_shared<DirectionalLight>();
	light->d = Eigen::Vector3d(0, 0, -1);
	light->I = Eigen::Vector3d(0.8, 0.8, 0.8);
	lights.push_back(light);
	
	// the materials
	std::vector<std::shared_ptr<Material>> materials;

	std::shared_ptr<Material> default_material = std::make_shared<Material>();
	default_material->ka = Eigen::Vector3d(0.3, 0.3, 0.3);
	default_material->kd = Eigen::Vector3d(0.0, 0.0, 1.0);
	default_material->ks = Eigen::Vector3d(0.3, 0.3, 1.0);
	default_material->km = Eigen::Vector3d(0.0, 0.0, 1.0);
	default_material->phong_exponent = 500;
	materials.push_back(default_material);

	std::shared_ptr<Material> m_glass = std::make_shared<Material>();
	m_glass->ka = Eigen::Vector3d(0.0596078,0.0305882,0.0639216);
	m_glass->kd = Eigen::Vector3d(0.596078,0.305882,0.639216);
	m_glass->ks = Eigen::Vector3d(0.596078,0.305882,0.639216);
	m_glass->km = Eigen::Vector3d(0.596078,0.305882,0.639216);
	m_glass->phong_exponent = 1;
	m_glass->refract_idx = 1.52;
	materials.push_back(m_glass);

	std::shared_ptr<Material> lava = std::make_shared<Material>();
	lava->ka = Eigen::Vector3d(0.0596078,0.0305882,0.0639216);
	lava->kd = Eigen::Vector3d(0.0596078,0.0305882,0.0639216);
	lava->ks = Eigen::Vector3d(0.0596078,0.0305882,0.0639216);
	lava->km = Eigen::Vector3d(0.0596078,0.0305882,0.0639216);
	lava->phong_exponent = 2000;
	materials.push_back(lava);

	std::vector<int> mesh_material_map = { 1 , 2, 2, 2, 0, 0};

	// Environment Mapping
	EnvironmentMapper env_mapper (data_dir + "background.png");

	std::vector<std::shared_ptr<Object>> scene_objects;	
	std::vector<Eigen::MatrixXd> Vs; // the meshes' vertices
	std::vector<Eigen::MatrixXi> Fs; // the meshes' faces
	std::vector<Eigen::MatrixXd> Ns; // the meshes' normals

	scene_objects.reserve(meshes.size());
	Vs.reserve(meshes.size());
	Fs.reserve(meshes.size());
	Ns.reserve(meshes.size());

	for (int m = 0; m < meshes.size(); m++) {	
		Eigen::MatrixXd V;
		Eigen::MatrixXi F;
		Eigen::MatrixXd N;

		Vs.push_back(V);
		Fs.push_back(F);
		Ns.push_back(N);

		igl::read_triangle_mesh(data_dir + meshes[m], Vs[m], Fs[m]);
		igl::per_corner_normals(Vs[m], Fs[m], 45, Ns[m]);	

		std::vector<std::shared_ptr<Object>> triangles;
		triangles.reserve(Fs[m].rows());

		for(int f = 0; f < Fs[m].rows();f++)
		{
			std::shared_ptr<TriangleMeshFace> tface = std::make_shared<TriangleMeshFace>(Vs[m], Fs[m], Ns[m], f);
			triangles.push_back(tface);
		}

		std::shared_ptr<AABBTree> root = std::make_shared<AABBTree>(triangles);
		root->material = materials[mesh_material_map[m]];
		scene_objects.push_back(root);
	}

	// keep matrices for each of the three colour channels of the image
	Eigen::Matrix<unsigned char, Eigen::Dynamic, Eigen::Dynamic> R(img_width, img_height);
	Eigen::Matrix<unsigned char, Eigen::Dynamic, Eigen::Dynamic> G(img_width, img_height);
	Eigen::Matrix<unsigned char, Eigen::Dynamic, Eigen::Dynamic> B(img_width, img_height);

	for(unsigned i = 0; i < img_height; ++i) {
		for(unsigned j = 0; j < img_width; ++j) {
			// Set background color
			Eigen::Vector3d rgb(0.0, 0.0, 0.0);

			// Compute viewing ray
			Ray ray;
			viewing_ray(camera, i, j, img_width, img_height, ray);
			
			// Shoot ray and collect color
			// [TODO] make the scene into a class that inherits from object
			raycolor(ray, 1.0, scene_objects, lights, env_mapper, 0, rgb);

			// Write double precision color into image
			auto clamp = [](double s){ return std::max(std::min(s, 1.0), 0.0); };

			R(j, img_height - 1 - i) = 255.0*clamp(rgb(0));
			G(j, img_height - 1 - i) = 255.0*clamp(rgb(1));
			B(j, img_height - 1 - i) = 255.0*clamp(rgb(2));
		}
	}

	Eigen::Matrix<unsigned char, Eigen::Dynamic, Eigen::Dynamic> A = 
	    Eigen::Matrix<unsigned char, Eigen::Dynamic, Eigen::Dynamic>::Constant(img_width, img_height, 255.0);

	igl::png::writePNG(R, G, B, A, out_image_name);
}